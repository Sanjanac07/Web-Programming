document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const movieId = Number(params.get("id"));
  const container = document.getElementById("movieDetailContainer");

  if (!container) return;

  const movie = window.movies?.find((item) => item.id === movieId);

  if (!movie) {
    container.innerHTML = `
      <div class="empty-state">
        <h3>Movie not found</h3>
        <p>Try browsing the catalog and select a film from the list.</p>
        <a href="movies.html" class="primary-btn">Back to movies</a>
      </div>
    `;
    return;
  }

  const watchlist = JSON.parse(localStorage.getItem("movieMateWatchlist") || "[]");
  const saved = watchlist.some((item) => item.id === movie.id);

  container.innerHTML = `
    <article class="movie-detail-card">
      <div class="detail-poster-wrap">
        <img src="${movie.image}" alt="${movie.title} poster" class="detail-poster" />
      </div>
      <div class="detail-content">
        <div class="detail-header-row">
          <div>
            <span class="eyebrow">${movie.genre}</span>
            <h1>${movie.title}</h1>
          </div>
          <button class="watchlist-toggle detail-toggle ${saved ? "saved" : ""}" data-id="${movie.id}" aria-label="Toggle watchlist for ${movie.title}">
            ${saved ? "✓ Saved" : "+ Add to watchlist"}
          </button>
        </div>

        <div class="movie-meta detail-meta">
          <span>${movie.year}</span>
          <span>${movie.runtime}</span>
          <span>⭐ ${movie.rating}</span>
          <span>${movie.mood}</span>
        </div>

        <p class="detail-description">${movie.description}</p>

        <div class="info-panel">
          <div>
            <h3>Cast</h3>
            <p>${movie.cast.join(", ")}</p>
          </div>
          <div>
            <h3>Story</h3>
            <p>${movie.description}</p>
          </div>
        </div>
      </div>
    </article>
  `;

  const toggleButton = document.querySelector(".detail-toggle");
  toggleButton?.addEventListener("click", () => {
    const current = JSON.parse(localStorage.getItem("movieMateWatchlist") || "[]");
    const exists = current.some((item) => item.id === movie.id);
    const updated = exists
      ? current.filter((item) => item.id !== movie.id)
      : [...current, { id: movie.id }];

    localStorage.setItem("movieMateWatchlist", JSON.stringify(updated));
    document.location.reload();
  });
});

