const movies = [
  {
    id: 1,
    title: "Midnight City",
    year: 2024,
    rating: 8.9,
    genre: "Drama",
    cast: ["Ava Brooks", "Noah Reed", "Mila Stone"],
    runtime: "2h 14m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=900&q=80",
    description:
      "A gifted musician returns home to confront a city of secrets, fading memories, and a future she never planned for.",
    featured: true,
  },
  {
    id: 2,
    title: "Neon Horizon",
    year: 2023,
    rating: 8.5,
    genre: "Sci-Fi",
    cast: ["Leo Hart", "Sofia Kim", "Ethan Cruz"],
    runtime: "2h 02m",
    mood: "Mind-bending",
    image:
      "https://images.unsplash.com/photo-1513106580091-1d82408b8cd6?auto=format&fit=crop&w=900&q=80",
    description:
      "In a future where memories can be traded, one woman must decide which version of herself deserves to survive.",
    featured: true,
  },
  {
    id: 3,
    title: "Golden Echo",
    year: 2022,
    rating: 8.1,
    genre: "Romance",
    cast: ["Emma Quinn", "Ryan Cole", "Ivy Mel"],
    runtime: "1h 55m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1524989941526-cf4a0d18fd2b?auto=format&fit=crop&w=900&q=80",
    description:
      "A radio host and a traveling photographer rediscover love through a series of chance encounters across the city.",
    featured: false,
  },
  {
    id: 4,
    title: "Shadow Run",
    year: 2021,
    rating: 8.8,
    genre: "Action & Adventure",
    cast: ["Dylan Brooks", "Mia Long", "Chris Vale"],
    runtime: "2h 08m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80",
    description:
      "A former operative is forced back into the field when a hidden conspiracy threatens the entire city.",
    featured: true,
  },
  {
    id: 5,
    title: "Velvet Skies",
    year: 2024,
    rating: 7.9,
    genre: "Adventure",
    cast: ["Nina Frost", "Theo Grant", "Lena Rowe"],
    runtime: "1h 50m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=900&q=80",
    description:
      "A young mapmaker and a stubborn pilot race across the clouds to uncover a secret world above the earth.",
    featured: false,
  },
  {
    id: 6,
    title: "Glass Revolution",
    year: 2020,
    rating: 8.6,
    genre: "Thriller & Mystery",
    cast: ["Harper Lane", "Jacob Bell", "Tara Moss"],
    runtime: "2h 19m",
    mood: "Mind-bending",
    image:
      "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?auto=format&fit=crop&w=900&q=80",
    description:
      "A journalist uncovers a chain of manipulated events and must outwit the system before it erases the truth.",
    featured: false,
  },
  {
    id: 7,
    title: "Crimson Tide",
    year: 2019,
    rating: 7.8,
    genre: "Action & Adventure",
    cast: ["Will Kade", "Ari Wells", "Sana Flores"],
    runtime: "1h 48m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1497032628192-86f99bcd76bc?auto=format&fit=crop&w=900&q=80",
    description:
      "When a coastal city is cut off by a violent storm, one rescue team becomes the last line of defense.",
    featured: false,
  },
  {
    id: 8,
    title: "Afterglow Avenue",
    year: 2024,
    rating: 8.3,
    genre: "Comedy",
    cast: ["Ruby Ford", "Miles Hall", "Jade Ellis"],
    runtime: "1h 42m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&w=900&q=80",
    description:
      "Three friends reopen a forgotten neighborhood theater and turn an unlikely summer into a joyful comeback story.",
    featured: false,
  },
  {
    id: 9,
    title: "Interstellar",
    year: 2014,
    rating: 8.7,
    genre: "Sci-Fi",
    cast: ["Matthew McConaughey", "Anne Hathaway", "Jessica Chastain"],
    runtime: "2h 49m",
    mood: "Mind-bending",
    image:
      "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=900&q=80",
    description:
      "A former pilot journeys through a wormhole in search of a new home for humanity.",
    featured: false,
  },
  {
    id: 10,
    title: "Inception",
    year: 2010,
    rating: 8.8,
    genre: "Sci-Fi",
    cast: ["Leonardo DiCaprio", "Joseph Gordon-Levitt", "Tom Hardy"],
    runtime: "2h 28m",
    mood: "Mind-bending",
    image:
      "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80",
    description:
      "A skilled thief enters dreams to plant an idea and change the course of a man's life.",
    featured: false,
  },
  {
    id: 11,
    title: "Avengers: Endgame",
    year: 2019,
    rating: 8.4,
    genre: "Superhero",
    cast: ["Robert Downey Jr.", "Chris Evans", "Scarlett Johansson"],
    runtime: "3h 1m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=900&q=80",
    description:
      "The remaining Avengers confront the aftermath of Thanos and fight for a final chance at redemption.",
    featured: false,
  },
  {
    id: 12,
    title: "Harry Potter and the Philosopher's Stone",
    year: 2001,
    rating: 7.6,
    genre: "Fantasy",
    cast: ["Daniel Radcliffe", "Rupert Grint", "Emma Watson"],
    runtime: "2h 32m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1513106580091-1d82408b8cd6?auto=format&fit=crop&w=900&q=80",
    description:
      "A young wizard discovers a magical world hidden behind the ordinary life he has always known.",
    featured: false,
  },
  {
    id: 13,
    title: "The Dark Knight",
    year: 2008,
    rating: 9.0,
    genre: "Superhero",
    cast: ["Christian Bale", "Heath Ledger", "Aaron Eckhart"],
    runtime: "2h 32m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=900&q=80",
    description:
      "Batman faces a criminal mastermind who turns chaos into a weapon against Gotham City.",
    featured: false,
  },
  {
    id: 14,
    title: "The Lord of the Rings: The Fellowship of the Ring",
    year: 2001,
    rating: 8.8,
    genre: "Fantasy",
    cast: ["Elijah Wood", "Ian McKellen", "Viggo Mortensen"],
    runtime: "2h 58m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80",
    description:
      "A young hobbit begins a perilous journey to destroy a powerful ring before darkness consumes Middle-earth.",
    featured: false,
  },
  {
    id: 15,
    title: "The Hobbit: An Unexpected Journey",
    year: 2012,
    rating: 7.8,
    genre: "Fantasy",
    cast: ["Martin Freeman", "Ian McKellen", "Richard Armitage"],
    runtime: "2h 49m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1524989941526-cf4a0d18fd2b?auto=format&fit=crop&w=900&q=80",
    description:
      "Bilbo Baggins embarks on a thrilling adventure with dwarves and a wizard to reclaim a homeland.",
    featured: false,
  },
  {
    id: 16,
    title: "The Chronicles of Narnia: The Lion, the Witch and the Wardrobe",
    year: 2005,
    rating: 7.0,
    genre: "Fantasy",
    cast: ["Georgie Henley", "Skandar Keynes", "William Moseley"],
    runtime: "2h 23m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&w=900&q=80",
    description:
      "Four siblings enter a magical wardrobe and discover a land under an eternal winter.",
    featured: false,
  },
  {
    id: 17,
    title: "Pirates of the Caribbean: The Curse of the Black Pearl",
    year: 2003,
    rating: 8.1,
    genre: "Fantasy",
    cast: ["Johnny Depp", "Orlando Bloom", "Keira Knightley"],
    runtime: "2h 23m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1497032628192-86f99bcd76bc?auto=format&fit=crop&w=900&q=80",
    description:
      "A cursed pirate captain, a young blacksmith, and a fearless governor collide in a swashbuckling adventure.",
    featured: false,
  },
  {
    id: 18,
    title: "Star Wars: A New Hope",
    year: 1977,
    rating: 8.6,
    genre: "Sci-Fi",
    cast: ["Mark Hamill", "Harrison Ford", "Carrie Fisher"],
    runtime: "2h 1m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&w=900&q=80",
    description:
      "A farm boy joins a rebellion against the Empire and discovers the power of hope.",
    featured: false,
  },
  {
    id: 19,
    title: "Dune",
    year: 2021,
    rating: 8.0,
    genre: "Sci-Fi",
    cast: ["Timothée Chalamet", "Rebecca Ferguson", "Zendaya"],
    runtime: "2h 35m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80",
    description:
      "A young nobleman becomes entangled in a war for a planet whose spice is the key to the universe.",
    featured: false,
  },
  {
    id: 20,
    title: "Avatar",
    year: 2009,
    rating: 7.9,
    genre: "Sci-Fi",
    cast: ["Sam Worthington", "Zoe Saldaña", "Sigourney Weaver"],
    runtime: "2h 42m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=900&q=80",
    description:
      "A marine joins a mission to Pandora, where he wrestles with duty and the wonder of a new world.",
    featured: false,
  },
  {
    id: 21,
    title: "The Matrix",
    year: 1999,
    rating: 8.7,
    genre: "Sci-Fi",
    cast: ["Keanu Reeves", "Laurence Fishburne", "Carrie-Anne Moss"],
    runtime: "2h 16m",
    mood: "Mind-bending",
    image:
      "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?auto=format&fit=crop&w=900&q=80",
    description:
      "A hacker discovers reality is a simulation and must choose between comfort and truth.",
    featured: false,
  },
  {
    id: 22,
    title: "Gladiator",
    year: 2000,
    rating: 8.5,
    genre: "Action & Adventure",
    cast: ["Russell Crowe", "Joaquin Phoenix", "Connie Nielsen"],
    runtime: "2h 35m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1513106580091-1d82408b8cd6?auto=format&fit=crop&w=900&q=80",
    description:
      "A betrayed Roman general rises through the arena to reclaim his honor and his vengeance.",
    featured: false,
  },
  {
    id: 23,
    title: "John Wick",
    year: 2014,
    rating: 7.4,
    genre: "Action & Adventure",
    cast: ["Keanu Reeves", "Michael Nyqvist", "Alfie Allen"],
    runtime: "1h 41m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80",
    description:
      "A retired assassin seeks vengeance after the murder of the dog that kept him alive.",
    featured: false,
  },
  {
    id: 24,
    title: "Indiana Jones and the Raiders of the Lost Ark",
    year: 1981,
    rating: 8.4,
    genre: "Action & Adventure",
    cast: ["Harrison Ford", "Karen Allen", "John Rhys-Davies"],
    runtime: "1h 55m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?auto=format&fit=crop&w=900&q=80",
    description:
      "A treasure hunter races across the globe to secure an ancient relic before the Nazis do.",
    featured: false,
  },
  {
    id: 25,
    title: "Top Gun: Maverick",
    year: 2022,
    rating: 8.3,
    genre: "Action & Adventure",
    cast: ["Tom Cruise", "Miles Teller", "Val Kilmer"],
    runtime: "2h 11m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=900&q=80",
    description:
      "A fearless pilot returns for a mission that tests both his skill and his courage.",
    featured: false,
  },
  {
    id: 26,
    title: "Mad Max: Fury Road",
    year: 2015,
    rating: 8.1,
    genre: "Action & Adventure",
    cast: ["Tom Hardy", "Charlize Theron", "Nicholas Hoult"],
    runtime: "2h 0m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80",
    description:
      "In a wasteland ruled by chaos, one woman and a rogue survivor race to freedom.",
    featured: false,
  },
  {
    id: 27,
    title: "Iron Man",
    year: 2008,
    rating: 7.9,
    genre: "Superhero",
    cast: ["Robert Downey Jr.", "Gwyneth Paltrow", "Jeff Bridges"],
    runtime: "2h 6m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80",
    description:
      "An inventor builds a powered armor suit and becomes the hero the world has been waiting for.",
    featured: false,
  },
  {
    id: 28,
    title: "The Avengers",
    year: 2012,
    rating: 8.0,
    genre: "Superhero",
    cast: ["Robert Downey Jr.", "Chris Evans", "Mark Ruffalo"],
    runtime: "2h 23m",
    mood: "Action rush",
    image:
      "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=900&q=80",
    description:
      "Earth's mightiest heroes unite to stop a global threat before it tears the world apart.",
    featured: false,
  },
  {
    id: 29,
    title: "Spider-Man: No Way Home",
    year: 2021,
    rating: 8.2,
    genre: "Superhero",
    cast: ["Tom Holland", "Zendaya", "Jacob Batalon"],
    runtime: "2h 28m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80",
    description:
      "Peter Parker's identity is exposed, forcing him into a multiverse adventure unlike any before.",
    featured: false,
  },
  {
    id: 30,
    title: "The Shawshank Redemption",
    year: 1994,
    rating: 9.3,
    genre: "Drama & Classics",
    cast: ["Tim Robbins", "Morgan Freeman", "Bob Gunton"],
    runtime: "2h 22m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?auto=format&fit=crop&w=900&q=80",
    description:
      "A banker forms an unlikely friendship while navigating hope, injustice, and endurance behind prison walls.",
    featured: false,
  },
  {
    id: 31,
    title: "Forrest Gump",
    year: 1994,
    rating: 8.8,
    genre: "Drama & Classics",
    cast: ["Tom Hanks", "Robin Wright", "Gary Sinise"],
    runtime: "2h 22m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&w=900&q=80",
    description:
      "A simple man with an extraordinary life navigates history, love, and loyalty with unwavering optimism.",
    featured: false,
  },
  {
    id: 32,
    title: "The Godfather",
    year: 1972,
    rating: 9.2,
    genre: "Drama & Classics",
    cast: ["Marlon Brando", "Al Pacino", "James Caan"],
    runtime: "2h 55m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=900&q=80",
    description:
      "A powerful crime family faces loyalty, betrayal, and succession in one of cinema's greatest sagas.",
    featured: false,
  },
  {
    id: 33,
    title: "Titanic",
    year: 1997,
    rating: 7.9,
    genre: "Drama & Classics",
    cast: ["Leonardo DiCaprio", "Kate Winslet", "Billy Zane"],
    runtime: "3h 14m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=900&q=80",
    description:
      "Two strangers from different worlds share a forbidden romance aboard the doomed RMS Titanic.",
    featured: false,
  },
  {
    id: 34,
    title: "The Green Mile",
    year: 1999,
    rating: 8.6,
    genre: "Drama & Classics",
    cast: ["Tom Hanks", "Michael Clarke Duncan", "David Morse"],
    runtime: "3h 9m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&w=900&q=80",
    description:
      "A death row guard forms an unforgettable bond with a miraculous prisoner whose fate is sealed.",
    featured: false,
  },
  {
    id: 35,
    title: "Home Alone",
    year: 1990,
    rating: 7.7,
    genre: "Comedy",
    cast: ["Macaulay Culkin", "Joe Pesci", "Daniel Stern"],
    runtime: "1h 43m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1497032628192-86f99bcd76bc?auto=format&fit=crop&w=900&q=80",
    description:
      "A resourceful young boy turns his family's empty home into a fortress against two burglars.",
    featured: false,
  },
  {
    id: 36,
    title: "The Hangover",
    year: 2009,
    rating: 7.7,
    genre: "Comedy",
    cast: ["Bradley Cooper", "Ed Helms", "Zach Galifianakis"],
    runtime: "1h 40m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1513106580091-1d82408b8cd6?auto=format&fit=crop&w=900&q=80",
    description:
      "Three friends wake up with no memory of a wild bachelor party and a missing groom.",
    featured: false,
  },
  {
    id: 37,
    title: "The Mask",
    year: 1994,
    rating: 6.9,
    genre: "Comedy",
    cast: ["Jim Carrey", "Cameron Diaz", "Peter Greene"],
    runtime: "1h 41m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&w=900&q=80",
    description:
      "A timid bank clerk discovers a magical mask that turns him into a chaotic, hilarious troublemaker.",
    featured: false,
  },
  {
    id: 38,
    title: "Mean Girls",
    year: 2004,
    rating: 7.1,
    genre: "Comedy",
    cast: ["Lindsay Lohan", "Rachel McAdams", "Tina Fey"],
    runtime: "1h 37m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1524989941526-cf4a0d18fd2b?auto=format&fit=crop&w=900&q=80",
    description:
      "A new student learns the rules of high-school hierarchy in the sharpest possible way.",
    featured: false,
  },
  {
    id: 39,
    title: "Mrs. Doubtfire",
    year: 1993,
    rating: 7.1,
    genre: "Comedy",
    cast: ["Robin Williams", "Sally Field", "Pierce Brosnan"],
    runtime: "2h 5m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&w=900&q=80",
    description:
      "A divorced father disguises himself as a nanny to stay close to his children.",
    featured: false,
  },
  {
    id: 40,
    title: "The Lion King",
    year: 1994,
    rating: 8.5,
    genre: "Animation",
    cast: ["Matthew Broderick", "Jeremy Irons", "James Earl Jones"],
    runtime: "1h 28m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=900&q=80",
    description:
      "A young lion must confront his past and accept the future of his kingdom.",
    featured: false,
  },
  {
    id: 41,
    title: "Toy Story",
    year: 1995,
    rating: 8.3,
    genre: "Animation",
    cast: ["Tom Hanks", "Tim Allen", "Don Rickles"],
    runtime: "1h 21m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=900&q=80",
    description:
      "A cowboy doll and a space ranger discover that friendship is the real adventure.",
    featured: false,
  },
  {
    id: 42,
    title: "Coco",
    year: 2017,
    rating: 8.4,
    genre: "Animation",
    cast: ["Anthony Gonzalez", "Gael García Bernal", "Benjamin Bratt"],
    runtime: "1h 45m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80",
    description:
      "A young musician traces his family's history through music, memory, and love.",
    featured: false,
  },
  {
    id: 43,
    title: "Frozen",
    year: 2013,
    rating: 7.4,
    genre: "Animation",
    cast: ["Kristen Bell", "Idina Menzel", "Jonathan Groff"],
    runtime: "1h 42m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=900&q=80",
    description:
      "Two sisters discover love, courage, and self-acceptance amid a kingdom of magic and snow.",
    featured: false,
  },
  {
    id: 44,
    title: "Shrek",
    year: 2001,
    rating: 7.9,
    genre: "Animation",
    cast: ["Mike Myers", "Eddie Murphy", "Cameron Diaz"],
    runtime: "1h 30m",
    mood: "Feel-good",
    image:
      "https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&w=900&q=80",
    description:
      "A grumpy ogre and a witty donkey set off on an adventure that warms the heart.",
    featured: false,
  },
  {
    id: 45,
    title: "Se7en",
    year: 1995,
    rating: 8.6,
    genre: "Thriller & Mystery",
    cast: ["Brad Pitt", "Morgan Freeman", "Gwyneth Paltrow"],
    runtime: "2h 7m",
    mood: "Mind-bending",
    image:
      "https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?auto=format&fit=crop&w=900&q=80",
    description:
      "Two detectives race to stop a serial killer whose murders follow the seven deadly sins.",
    featured: false,
  },
  {
    id: 46,
    title: "The Prestige",
    year: 2006,
    rating: 8.5,
    genre: "Thriller & Mystery",
    cast: ["Christian Bale", "Hugh Jackman", "Scarlett Johansson"],
    runtime: "2h 10m",
    mood: "Mind-bending",
    image:
      "https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?auto=format&fit=crop&w=900&q=80",
    description:
      "Two rival magicians escalate a decades-long obsession into an intricate battle of illusion.",
    featured: false,
  },
  {
    id: 47,
    title: "Shutter Island",
    year: 2010,
    rating: 8.2,
    genre: "Thriller & Mystery",
    cast: ["Leonardo DiCaprio", "Mark Ruffalo", "Ben Kingsley"],
    runtime: "2h 18m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80",
    description:
      "A U.S. marshal investigates a missing patient on a windswept island that hides darker truths.",
    featured: false,
  },
  {
    id: 48,
    title: "Gone Girl",
    year: 2014,
    rating: 8.1,
    genre: "Thriller & Mystery",
    cast: ["Ben Affleck", "Rosamund Pike", "Neil Patrick Harris"],
    runtime: "2h 29m",
    mood: "Mind-bending",
    image:
      "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=900&q=80",
    description:
      "A woman disappears on the eve of her fifth wedding anniversary, and everyone becomes a suspect.",
    featured: false,
  },
  {
    id: 49,
    title: "Knives Out",
    year: 2019,
    rating: 7.9,
    genre: "Thriller & Mystery",
    cast: ["Daniel Craig", "Ana de Armas", "Chris Evans"],
    runtime: "2h 10m",
    mood: "Mind-bending",
    image:
      "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80",
    description:
      "A brilliant detective uncovers a web of family secrets and escalating lies.",
    featured: false,
  },
  {
    id: 50,
    title: "The Conjuring",
    year: 2013,
    rating: 7.5,
    genre: "Horror",
    cast: ["Vera Farmiga", "Patrick Wilson", "Ron Livingston"],
    runtime: "1h 52m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=900&q=80",
    description:
      "A couple investigates a haunting that grows more intense with every passing night.",
    featured: false,
  },
  {
    id: 51,
    title: "The Shining",
    year: 1980,
    rating: 8.4,
    genre: "Horror",
    cast: ["Jack Nicholson", "Shelley Duvall", "Danny Lloyd"],
    runtime: "2h 26m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80",
    description:
      "An isolated hotel and a spiraling father make for a nightmare that never ends.",
    featured: false,
  },
  {
    id: 52,
    title: "Scream",
    year: 1996,
    rating: 7.2,
    genre: "Horror",
    cast: ["Neve Campbell", "Courteney Cox", "David Arquette"],
    runtime: "1h 51m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1513106580091-1d82408b8cd6?auto=format&fit=crop&w=900&q=80",
    description:
      "A masked killer targets a small town of teens who realize the rules of horror are changing.",
    featured: false,
  },
  {
    id: 53,
    title: "A Quiet Place",
    year: 2018,
    rating: 7.5,
    genre: "Horror",
    cast: ["Emily Blunt", "John Krasinski", "Millicent Simmonds"],
    runtime: "1h 30m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&w=900&q=80",
    description:
      "A family must live in deadly silence to survive monsters that hunt by sound.",
    featured: false,
  },
  {
    id: 54,
    title: "Alien",
    year: 1979,
    rating: 8.4,
    genre: "Horror",
    cast: ["Sigourney Weaver", "Tom Skerritt", "John Hurt"],
    runtime: "1h 57m",
    mood: "Late-night watch",
    image:
      "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=900&q=80",
    description:
      "A commercial crew discovers a horrifying life form aboard a distant spaceship.",
    featured: false,
  },
];

const posterMap = {
  "Interstellar": "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg",
  "Inception": "https://image.tmdb.org/t/p/w500/edv5CZvWj09upOsy2Y6IwDhKOk.jpg",
  "Avengers: Endgame": "https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg",
  "Harry Potter and the Philosopher's Stone": "https://image.tmdb.org/t/p/w500/wuMcuxIL6e0JtM6dH0Jv0Q5VB1E.jpg",
  "The Dark Knight": "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg",
  "The Lord of the Rings: The Fellowship of the Ring": "https://image.tmdb.org/t/p/w500/6oom5QYQ2yQTMJIbnvbkBL9cHo6.jpg",
  "The Hobbit: An Unexpected Journey": "https://image.tmdb.org/t/p/w500/yHA9Fc37VmpUA5UncT3K2jjs0KJ.jpg",
  "The Chronicles of Narnia: The Lion, the Witch and the Wardrobe": "https://image.tmdb.org/t/p/w500/liNNwiEaVn2z0Xbx4i5I4hO0W7Y.jpg",
  "Pirates of the Caribbean: The Curse of the Black Pearl": "https://image.tmdb.org/t/p/w500/z8onk7LV9M5Xf9nD5Xy1sBfUQbY.jpg",
  "Star Wars: A New Hope": "https://image.tmdb.org/t/p/w500/btTdmkgIvOi0FFip1sPuZI2oQG6.jpg",
  "Dune": "https://image.tmdb.org/t/p/w500/d5NXSklUhu2kA9Q3m5n7w0u4qP.jpg",
  "Avatar": "https://image.tmdb.org/t/p/w500/jRXYj8OcvN3uA4hWgkWnz8dqZug.jpg",
  "The Matrix": "https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg",
  "Gladiator": "https://image.tmdb.org/t/p/w500/ty8TGRuvJLPUmAR1H1nRIsgwvim.jpg",
  "John Wick": "https://image.tmdb.org/t/p/w500/fZPSd91yGE9fCB6L5a5qH1ZzZkU.jpg",
  "Indiana Jones and the Raiders of the Lost Ark": "https://image.tmdb.org/t/p/w500/cezWGskPY5x7GaglTTRN4Fugfb8.jpg",
  "Top Gun: Maverick": "https://image.tmdb.org/t/p/w500/62HCnUTziyWcpDaBO2i1DX17ljH.jpg",
  "Mad Max: Fury Road": "https://image.tmdb.org/t/p/w500/8tZYJkLh0vpN5kAwqavC6mbR0vN.jpg",
  "Iron Man": "https://image.tmdb.org/t/p/w500/78lPtwv72eTNqFW9COBYlXgh4W.jpg",
  "The Avengers": "https://image.tmdb.org/t/p/w500/RYMX2wcKCBAr24UyPD7xwmjaTn.jpg",
  "Spider-Man: No Way Home": "https://image.tmdb.org/t/p/w500/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg",
  "The Shawshank Redemption": "https://image.tmdb.org/t/p/w500/q6y0Go1tsGEsmtFryDOJo3dEmqu.jpg",
  "Forrest Gump": "https://image.tmdb.org/t/p/w500/arw2vcBq9z2uJFXTj7c2f44T0vQ.jpg",
  "The Godfather": "https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsRolD1fZdja1.jpg",
  "Titanic": "https://image.tmdb.org/t/p/w500/9xjZS2rlVxm8SFx8kPC3aIGCOYQ.jpg",
  "The Green Mile": "https://image.tmdb.org/t/p/w500/velWPhVMQeQK5bbM7o3LbJ5Z6l0.jpg",
  "Home Alone": "https://image.tmdb.org/t/p/w500/1VQ1uQoNwjlO5pcpUGonrZyru5J.jpg",
  "The Hangover": "https://image.tmdb.org/t/p/w500/ddyQJzj1u7F5x0C6jDsk7M1q0i.jpg",
  "The Mask": "https://image.tmdb.org/t/p/w500/1l8TKqqK51HeQzCkSgIYV9K4o3Y.jpg",
  "Mean Girls": "https://image.tmdb.org/t/p/w500/szfT9YtU5nPqMwW3Hn6y70bEF4Z.jpg",
  "Mrs. Doubtfire": "https://image.tmdb.org/t/p/w500/uKJEtF1I4nDg9QyK5sQ5F3gFVa9.jpg",
  "The Lion King": "https://image.tmdb.org/t/p/w500/bpg6O9dffn5Gk7CtW9f4mMhUouO.jpg",
  "Toy Story": "https://image.tmdb.org/t/p/w500/uXDfjJbdP4ijW5hWSBrPrlKpxab.jpg",
  "Coco": "https://image.tmdb.org/t/p/w500/gGEsBPAJ4X9I2gqT0Q7mS7rF7q0.jpg",
  "Frozen": "https://image.tmdb.org/t/p/w500/kFB1dU7zXK9c7nK3LT5mNQJ5QzA.jpg",
  "Shrek": "https://image.tmdb.org/t/p/w500/d3QyQzAq4G6CkNV0K4j9AXsM8rD.jpg",
  "Se7en": "https://image.tmdb.org/t/p/w500/6yoghtyTpznpB5M8Jm3lH0kM7pI.jpg",
  "The Prestige": "https://image.tmdb.org/t/p/w500/c5eL3xgJ4y4cf0nKfV0lQpV6Wm5.jpg",
  "Shutter Island": "https://image.tmdb.org/t/p/w500/kve5lA7KJmJr0k9ZsyD3U0xkXWm.jpg",
  "Gone Girl": "https://image.tmdb.org/t/p/w500/4f5Z4hD2kD9iP7x9ZK2sV0CP0mF.jpg",
  "Knives Out": "https://image.tmdb.org/t/p/w500/kNf5gK9W1m5r5kQ4Tz4wM7oP8ZD.jpg",
  "The Conjuring": "https://image.tmdb.org/t/p/w500/wVYREutTvI2tmxr6ujrHTPG7xE.jpg",
  "The Shining": "https://image.tmdb.org/t/p/w500/xb4A4u5A0R0K0s6Vh9Q0u0JtW5M.jpg",
  "Scream": "https://image.tmdb.org/t/p/w500/8m9k1T2p3sA5k8u8c4I4X4uQ1dN.jpg",
  "A Quiet Place": "https://image.tmdb.org/t/p/w500/4qMfeerQGQ0PlVdeOTe0CzIDlA7.jpg",
  "Alien": "https://image.tmdb.org/t/p/w500/vfrQk5IPloGg1v9R4D6H7uB1knN.jpg",
};

movies.forEach((movie) => {
  if (posterMap[movie.title]) {
    movie.image = posterMap[movie.title];
  }
});

window.movies = movies;

const getStoredWatchlist = () => {
  try {
    return JSON.parse(localStorage.getItem("movieMateWatchlist") || "[]");
  } catch {
    return [];
  }
};

const saveWatchlist = (watchlist) => {
  localStorage.setItem("movieMateWatchlist", JSON.stringify(watchlist));
};

const createMovieCard = (movie) => {
  const watchlist = getStoredWatchlist();
  const isSaved = watchlist.some((item) => item.id === movie.id);

  return `
    <article class="movie-card">
      <div class="movie-poster-wrapper">
        <img src="${movie.image}" alt="${movie.title} poster" class="movie-poster" />
        <button class="watchlist-toggle ${isSaved ? "saved" : ""}" data-id="${movie.id}" aria-label="Toggle watchlist for ${movie.title}">
          ${isSaved ? "✓ Saved" : "+ Watchlist"}
        </button>
      </div>
      <div class="movie-card-body">
        <div class="movie-card-header">
          <div>
            <p class="movie-genre">${movie.genre}</p>
            <h3>${movie.title}</h3>
          </div>
          <span class="movie-rating">⭐ ${movie.rating}</span>
        </div>
        <div class="movie-meta">
          <span>${movie.year}</span>
          <span>${movie.runtime}</span>
          <span>${movie.mood}</span>
        </div>
        <p class="movie-summary">${movie.description}</p>
        <a href="movie-details.html?id=${movie.id}" class="details-link">View details</a>
      </div>
    </article>
  `;
};

const genreCollections = {
  Trending: [
    "Interstellar",
    "Inception",
    "Avengers: Endgame",
    "Harry Potter and the Philosopher's Stone",
    "The Dark Knight",
  ],
  Fantasy: [
    "Harry Potter and the Philosopher's Stone",
    "The Lord of the Rings: The Fellowship of the Ring",
    "The Hobbit: An Unexpected Journey",
    "The Chronicles of Narnia: The Lion, the Witch and the Wardrobe",
    "Pirates of the Caribbean: The Curse of the Black Pearl",
  ],
  "Sci-Fi": [
    "Star Wars: A New Hope",
    "Interstellar",
    "Dune",
    "Avatar",
    "The Matrix",
  ],
  "Action & Adventure": [
    "Gladiator",
    "John Wick",
    "Indiana Jones and the Raiders of the Lost Ark",
    "Top Gun: Maverick",
    "Mad Max: Fury Road",
  ],
  Superhero: [
    "Iron Man",
    "The Avengers",
    "Avengers: Endgame",
    "Spider-Man: No Way Home",
    "The Dark Knight",
  ],
  "Drama & Classics": [
    "The Shawshank Redemption",
    "Forrest Gump",
    "The Godfather",
    "Titanic",
    "The Green Mile",
  ],
  Comedy: [
    "Home Alone",
    "The Hangover",
    "The Mask",
    "Mean Girls",
    "Mrs. Doubtfire",
  ],
  Animation: [
    "The Lion King",
    "Toy Story",
    "Coco",
    "Frozen",
    "Shrek",
  ],
  "Thriller & Mystery": [
    "Se7en",
    "The Prestige",
    "Shutter Island",
    "Gone Girl",
    "Knives Out",
  ],
  Horror: [
    "The Conjuring",
    "The Shining",
    "Scream",
    "A Quiet Place",
    "Alien",
  ],
};

const renderFeaturedMovies = () => {
  const featured = movies.filter((movie) => movie.featured).slice(0, 3);
  const target = document.getElementById("featured-grid");

  if (!target) return;
  target.innerHTML = featured.map((movie) => createMovieCard(movie)).join("");
  bindWatchlistControls();
};

const renderGenreSections = () => {
  const container = document.getElementById("genreCollections");
  if (!container) return;

  const sections = Object.entries(genreCollections)
    .map(([genreName, titles]) => {
      const cards = titles
        .map((title) => {
          const movie = movies.find((item) => item.title === title);
          return movie ? createMovieCard(movie) : "";
        })
        .join("");

      const filterUrl = `movies.html?genre=${encodeURIComponent(genreName)}`;

      return `
        <section class="genre-section genre-collection">
          <div class="section-heading genre-heading">
            <h2>${genreName}</h2>
            <a href="${filterUrl}" class="text-link">Discover More →</a>
          </div>
          <div class="movie-grid genre-grid">${cards}</div>
        </section>
      `;
    })
    .join("");

  container.innerHTML = sections;
  bindWatchlistControls();
};

const renderMoviesList = () => {
  const target = document.getElementById("moviesGrid");
  if (!target) return;

  const params = new URLSearchParams(window.location.search);
  const genreFromQuery = params.get("genre");
  const searchTerm = document.getElementById("searchInput")?.value.trim().toLowerCase() || "";
  const selectedGenre = document.getElementById("genreFilter")?.value || genreFromQuery || "all";
  const sortBy = document.getElementById("sortFilter")?.value || "featured";

  let filteredMovies = [...movies];

  if (searchTerm) {
    filteredMovies = filteredMovies.filter(
      (movie) =>
        movie.title.toLowerCase().includes(searchTerm) ||
        movie.genre.toLowerCase().includes(searchTerm) ||
        movie.mood.toLowerCase().includes(searchTerm)
    );
  }

  if (selectedGenre !== "all") {
    filteredMovies = filteredMovies.filter((movie) => movie.genre === selectedGenre);
  }

  if (sortBy === "rating") {
    filteredMovies.sort((a, b) => b.rating - a.rating);
  } else if (sortBy === "year") {
    filteredMovies.sort((a, b) => b.year - a.year);
  } else if (sortBy === "title") {
    filteredMovies.sort((a, b) => a.title.localeCompare(b.title));
  }

  target.innerHTML = filteredMovies.map((movie) => createMovieCard(movie)).join("");
  bindWatchlistControls();
};

const populateGenres = () => {
  const target = document.getElementById("genreFilter");
  if (!target) return;

  const genres = [...new Set(movies.map((movie) => movie.genre))];
  const options = genres
    .map((genre) => `<option value="${genre}">${genre}</option>`)
    .join("");

  target.insertAdjacentHTML("beforeend", options);

  const params = new URLSearchParams(window.location.search);
  const selectedGenre = params.get("genre");
  if (selectedGenre && [...target.options].some((option) => option.value === selectedGenre)) {
    target.value = selectedGenre;
  }
};

const renderWatchlist = () => {
  const target = document.getElementById("watchlistContainer");
  if (!target) return;

  const watchlist = getStoredWatchlist();

  if (!watchlist.length) {
    target.innerHTML = `
      <div class="empty-state">
        <h3>Your watchlist is empty</h3>
        <p>Start exploring the collection and save the movies you want to watch next.</p>
        <a href="movies.html" class="primary-btn">Browse movies</a>
      </div>
    `;
    bindWatchlistControls();
    return;
  }

  const savedMovies = movies.filter((movie) => watchlist.some((item) => item.id === movie.id));
  target.innerHTML = savedMovies.map((movie) => createMovieCard(movie)).join("");
  bindWatchlistControls();
};

const toggleWatchlist = (movieId) => {
  const current = getStoredWatchlist();
  const exists = current.some((item) => item.id === movieId);
  const updated = exists ? current.filter((item) => item.id !== movieId) : [...current, { id: movieId }];

  saveWatchlist(updated);

  if (document.body.dataset.page === "watchlist") {
    renderWatchlist();
  }

  if (document.body.dataset.page === "movies" || document.body.dataset.page === "home") {
    renderMoviesList();
    renderFeaturedMovies();
  }
};

const bindWatchlistControls = () => {
  document.querySelectorAll(".watchlist-toggle").forEach((button) => {
    button.addEventListener("click", () => {
      toggleWatchlist(Number(button.dataset.id));
    });
  });
};

const initializeMoviePage = () => {
  populateGenres();
  renderMoviesList();
  bindWatchlistControls();

  const searchInput = document.getElementById("searchInput");
  const genreFilter = document.getElementById("genreFilter");
  const sortFilter = document.getElementById("sortFilter");

  searchInput?.addEventListener("input", () => {
    renderMoviesList();
    bindWatchlistControls();
  });

  genreFilter?.addEventListener("change", () => {
    renderMoviesList();
    bindWatchlistControls();
  });

  sortFilter?.addEventListener("change", () => {
    renderMoviesList();
    bindWatchlistControls();
  });
};

const initializeHomePage = () => {
  renderFeaturedMovies();
  renderGenreSections();
  bindWatchlistControls();
};

const initializeWatchlistPage = () => {
  renderWatchlist();
  bindWatchlistControls();
};

const renderMovieDetails = () => {
  const container = document.getElementById("movieDetailContainer");
  if (!container) return;

  const params = new URLSearchParams(window.location.search);
  const movieId = Number(params.get("id"));
  const movie = movies.find((item) => item.id === movieId);

  if (!movie) {
    container.innerHTML = `
      <div class="empty-state">
        <h3>Movie not found</h3>
        <p>Try browsing the full catalog and select a film from the list.</p>
        <a href="movies.html" class="primary-btn">Back to movies</a>
      </div>
    `;
    return;
  }

  const watchlist = getStoredWatchlist();
  const isSaved = watchlist.some((item) => item.id === movie.id);

  container.innerHTML = `
    <article class="movie-detail-card">
      <div class="detail-poster-wrap">
        <img src="${movie.image}" alt="${movie.title} poster" class="detail-poster" />
      </div>
      <div class="detail-content">
        <div class="detail-header-row">
          <div>
            <span class="eyebrow">${movie.genre}</span>
            <h1>${movie.title}</h1>
          </div>
          <button class="watchlist-toggle detail-toggle ${isSaved ? "saved" : ""}" data-id="${movie.id}">
            ${isSaved ? "✓ Saved" : "+ Add to watchlist"}
          </button>
        </div>

        <div class="movie-meta detail-meta">
          <span>${movie.year}</span>
          <span>${movie.runtime}</span>
          <span>⭐ ${movie.rating}</span>
          <span>${movie.mood}</span>
        </div>

        <p class="detail-description">${movie.description}</p>

        <div class="info-panel">
          <div>
            <h3>Cast</h3>
            <p>${movie.cast.join(", ")}</p>
          </div>
          <div>
            <h3>Story</h3>
            <p>${movie.description}</p>
          </div>
        </div>
      </div>
    </article>
  `;

  const detailToggle = document.querySelector(".detail-toggle");
  detailToggle?.addEventListener("click", () => {
    toggleWatchlist(Number(detailToggle.dataset.id));
    renderMovieDetails();
  });
};

const setCurrentYear = () => {
  document.querySelectorAll("#current-year").forEach((yearEl) => {
    yearEl.textContent = new Date().getFullYear();
  });
};

document.addEventListener("DOMContentLoaded", () => {
  setCurrentYear();

  const page = document.body.dataset.page;

  if (page === "home") initializeHomePage();
  if (page === "movies") initializeMoviePage();
  if (page === "watchlist") initializeWatchlistPage();
  if (page === "details") renderMovieDetails();
});
